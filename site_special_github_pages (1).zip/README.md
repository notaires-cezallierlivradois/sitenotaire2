# Site de l’Office notarial — GitHub Pages

Ce dossier est prêt pour un déploiement sur **GitHub Pages**.

## Déploiement
1. Créez un dépôt public.
2. Glissez l’ensemble de ces fichiers (ne pas zipper).
3. Dans **Settings → Pages** :
   - *Source* : `Deploy from branch`
   - *Branch* : `main` ; *Folder* : `/ (root)`
4. Enregistrez : l’URL sera `https://<votre-identifiant>.github.io/<nom-du-depot>/`.

### Domaines personnalisés (optionnel)
Ajoutez un fichier `CNAME` à la racine du dépôt contenant votre domaine (ex. `office-cezallierlivradois.fr`).

### Note
Le fichier `.nojekyll` désactive le traitement Jekyll afin de servir tous les fichiers tels quels.
